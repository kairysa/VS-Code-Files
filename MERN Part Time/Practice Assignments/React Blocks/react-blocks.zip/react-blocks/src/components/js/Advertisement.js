import React from 'react';
import '../css/style.css';

const Advertisement = (props) => {
    return (
        <div className="ad">
        </div>
    )
}

export default Advertisement;