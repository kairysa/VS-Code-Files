import React from 'react';
import '../css/style.css';

const Subcontent = (props) => {
    return (
        <div className="d-flex">
            <div className="subcontent col-sm"></div>
            <div className="subcontent col-sm"></div>
            <div className="subcontent col-sm"></div>
        </div>
    )
}

export default Subcontent;