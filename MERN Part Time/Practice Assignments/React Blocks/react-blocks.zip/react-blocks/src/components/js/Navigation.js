import React from 'react';
import '../css/style.css';

const Navigation = (props) => {
    return (
        <div className="nav"></div>
    )
}

export default Navigation;